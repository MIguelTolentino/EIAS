<?php
	$server = 'localhost';
	$user = 'root';
	$pass = '';
	$db = 'eias';

	$con = new mysqli($server,$user,$pass,$db);


?>

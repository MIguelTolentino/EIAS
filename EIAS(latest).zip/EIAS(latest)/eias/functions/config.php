<?php 
	$server = 'localhost';
	$user = 'u623987209_eias';
	$pass = '2^B~zVXr';
	$db = 'u623987209_eias_db';

	$con = new mysqli($server,$user,$pass,$db);

	
?>